#include <stdio.h>

int main(){
    int num;
    
    printf("digite um numero : ");
    scanf("%d",&num);

    if(num > 100){
        printf("%d",num);
    }else{
        printf("0");

    }












    return 0 ;
}