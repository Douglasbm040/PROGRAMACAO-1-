#include <stdio.h>

int main (){
 int senha ;
 printf("digite a senha : ");
 scanf("%d",&senha);
 
 if(senha == 4531 ){
    printf("acesso liberado");
 }else{
     printf("senha incorreta ! ");
 }




    return 0 ;
}